<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="utf-8"/>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="theme-color" content="00C3A5"/>
<title>Powermeter</title>
<link rel="stylesheet" media="all" href="/assets/css/screen.css"/>
<link rel="stylesheet" media="all" href="/assets/css/_calendar.css"/>
<link rel="stylesheet" media="all" href="/assets/css/min/style.min.css"/>
<link rel="icon" type="image/png" sizes="32x32" href="/assets/images/favicon-32x32.png">
<link rel="icon" type="image/png" sizes="16x16" href="/assets/images/favicon-16x16.png">


    <link rel="stylesheet" href="https://cdn.datatables.net/1.10.19/css/dataTables.semanticui.min.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/responsive/2.2.3/css/responsive.semanticui.min.css">
    <!-- SEMANTIC UI-->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/semantic-ui@2.4.2/dist/semantic.min.css">
    <!-- Font Awesome-->
    <script src="https://kit.fontawesome.com/c43c022dac.js" crossorigin="anonymous"></script>
</head>
<body class="resumenBB plantaSelector">
<header class="site-header header--fixed">
    <div class="sidebarControl">
        <div class="logo logo--size-sm" id="logoSidebar"></div>
    </div>

    <!--a href="#" class="" id="sidebarControl">
        <i class="fas fa-bars"></i>
    </a-->


    <a href="#" class="btn-hamburger"><span></span></a>
    <div class="site-header__menu">
        <a href="#" class="btn-close"></a>
        <nav class="site-header__nav">
            <a href="" class="item" data-tooltip="Notificaciones" data-position="bottom right">
                <img alt="" src="assets/images/campana.png">
            </a>
            <a href="configuracion.php" class="item configuracionTop" data-tooltip="Configuración" data-position="bottom right">
                <img alt="" src="assets/images/config.png">
            </a>
            <a href="soporte.php" class="soporteTop" data-tooltip="Soporte" data-position="bottom right">
                <img alt="" src="assets/images/faqs.png">
            </a>
            <a id="logout" href="" data-username="Nombre Apellido" data-tooltip="Log Out" data-position="bottom right">
                <img alt="" src="assets/images/logout.png">
            </a>
        </nav>
        <!--/header-nav-->
        <ul class="site-header__data">
            <li>Sucre 942, PB2, CABA.</li>
            <li>(011) 6091-4859</li>
            <li>Ventas: ventas@powermeter.com.ar</li>
            <li>Consultas Técnicas: info@powermeter.com.ar</li>
        </ul>
        <div class="logo logo--white logo--size-sm logo--opacity-60"></div>
    </div>
</header>

<nav class="main-menu">
    <ul class="accordionUl">
        <div class="ui vertical accordion menu">
            <div class="item simulatedMenu">
                <i class="fas fa-bars"></i>
            </div>
            <div class="item resumenSection">
                <a class="title withSub withoutAfter">
                    <img alt="" src="assets/images/first-menu.png" style="width:26px; height:26px;">
                    <span class="nav-text">
                        Resumen
                    </span>
                    <!--h4 class="showTitle">Resumen</h4-->
                </a>
                <div class="content">
                    <ul>
                        <li>
                            <a href="index.php">Dashboard</a>
                        </li>
                        <li>
                            <a href="mapa.php">Mapa</a>
                        </li>
                        <!--li>
                            <a href="lista.php">Lista</a>
                        </li-->
                        <li>
                            <a href="planta.php">Planta</a>
                        </li>
                    </ul>
                </div>
            </div>
            <div class="item">
                <a href="facturacion.php" class="title withoutAfter onlyLink">
                    <img alt="" src="assets/images/five-menu.png" style="width:26px; height:26px;">
                    <span class="nav-text">
                        Facturación
                    </span>
                    <!--h4 class="showTitle">Facturación</h4-->
                </a>
            </div>
            <div class="item">
                <a class="title withoutAfter onlyLink">
                    <img alt="" src="assets/images/second-menu.png" style="width:26px; height:26px;">
                    <span class="nav-text">
                        Auditor
                    </span>
                    <!--h4 class="showTitle">Auditor</h4-->
                </a>
            </div>
            <div class="item deSeparador"></div>
            <div class="item analisisSection">
                <a class="title withSub withoutAfter">
                    <img alt="" src="assets/images/four-menu.png" style="width:26px; height:26px;">
                    <span class="nav-text">
                        Análisis
                    </span>
                    <!--h4 class="showTitle">Análisis</h4-->
                </a>
                <div class="content">
                    <ul>
                        <li>
                            <a href="instantaneos.php">Instantáneos</a>
                        </li>
                        <li>
                            <a href="historicos.php">Históricos</a>
                        </li>
                        <li>
                            <a href="calidad.php">Calidad</a>
                        </li>
                        <li>
                            <a href="stand-by.php">Stand-by</a>
                        </li>
                        <li>
                            <a href="eventos.php">Eventos</a>
                        </li>
                    </ul>
                </div>
            </div>
            <div class="item">
                <a class="title withoutAfter onlyLink">
                    <img alt="" src="assets/images/six-menu.png" style="width:26px; height:26px;">
                    <span class="nav-text">
                        Control
                    </span>
                    <!--h4 class="showTitle">Control</h4-->
                </a>
            </div>
        </div>
    </ul>
    <!--ul class="logout">
        <li>
           <a href="#" class="containDesc" id="closeSidebar" data-tooltip="Abrir menú" data-position="top left">
                 <i class="fas fa-chevron-right"></i>
                <span class="nav-text">

                </span>
            </a>
        </li>
    </ul-->
</nav>

<div class="dimDiv"></div>



<script>
    $('.ui.accordion').accordion({'exclusive': false});
</script>

<div class="block block--device bg-color cursorDif withSideMenu">
        <div class="ui secondary pointing menu custom-menu customBread">
            <div class="oneColumn">
                <p class="customBreadText">Resumen <span>| Planta</span></p>
            </div>

            <div class="secondColumn">
                <p class="filterDesc">
                    <span>Localización x.x</span>
                </p>
                <p style="cursor:pointer;" class="filterDesc" id="showInfoMarkers" data-tooltip="Mostrar información de todos los dispositivos" data-position="bottom right">
                    <i style="width:auto; height:auto;" class="fas fa-info-circle"></i>
                </p>

                <div class="ui vertical labeled open-filters" onclick="$('#hidden-menu').fadeToggle('500');$('.open-filters,.close-filters').toggle();">
                  <button id="button-event" class="ui labeled icon button filter-home">
                    <i class="filter icon filter-home"></i>
                    <p>Filtrar</p>
                  </button>
                </div>
                <div class="ui vertical labeled close-filters" style="display: none;" onclick="$('#hidden-menu').fadeToggle('500');$('.open-filters,.close-filters').toggle();">
                  <button id="button-event" class="ui labeled icon button filter-home">
                    <i class="close icon filter-home"></i>
                    <p>Filtrar</p>
                  </button>
                </div>

            </div>
        </div>

        <div class="container-full">

            <section class="block block--devices" id="planta">



                    <div id="hidden-menu" class="ui equal width center aligned padded grid newConfig borderLineInstant bg-white" style="display: none;">
                        <div class="row information">
                            <div class="column">
                                <div class="ui two column grid equal height stackable">
                                        <div class="row">
                                            <div class="column">
                                                <form class="ui form gralForm">

                                                    <div class="field">
                                                        <label class="typeTitle">Localización:</label>
                                                        <div class="ui selection dropdown">
                                                            <div class="default text textSelect">Seleccionar</div>
                                                            <i class="dropdown icon"></i>
                                                            <input type="hidden" name="gender">
                                                            <div class="menu">
                                                                <div class="item" data-value="grupo">Localización 1.0</div>
                                                                <div class="item" data-value="nivel">Localización 1.1</div>
                                                                <div class="item" data-value="nivel">Localización 1.2</div>
                                                            </div>
                                                        </div>
                                                    </div>

                                                    <div class="">
                                                        <a href="" class="ui btnOk mtb-25">Consultar</a>
                                                    </div>
                                                </form>
                                            </div>
                                            <div class="column">
                                                <div class="tableDispositivos">
                                                    <table class="ui celled table generalTables plantaTable">
                                                        <thead>
                                                            <tr>
                                                                <th>Dispositivo</th>
                                                                <th>Ubicado</th>
                                                                <th></th>
                                                                <th></th>
                                                            </tr>
                                                        </thead>
                                                        <tbody>
                                                            <!--CAMBIAR LA CLASE "NEGATIVE" A "POSITIVE" EN EL TD "NO UBICADO/UBICADO" PARA MOSTRAR CUANDO ESTA O NO UBICADO Y "CLOSE" POR "CHECKMARK"-->
                                                            <tr>
                                                                <td>Dispositivo 1.0</td>
                                                                <td class="negative placedOrNot"><i class="icon close"></i> <span>No ubicado</span></td>
                                                                <td class="text-center"><a class="ubicarDisp ubicarMarker cursorPointer" data-tooltip="Ubicar" data-position="top center"><i class="fas fa-map-marker-alt"></i></a></td>
                                                                <td class="text-center"><a class="ubicarDisp quitarMarker cursorPointer ubicado" data-tooltip="Quitar" data-position="top center"><i class="far fa-trash-alt"></i></a></td>
                                                            </tr>
                                                            <tr>
                                                                <td>Dispositivo 1.1</td>
                                                                <td class="negative"><i class="icon close"></i> <span>No Ubicado</span></td>
                                                                <td class="text-center"><a class="ubicarDisp cursorPointer" data-tooltip="Ubicar" data-position="top center"><i class="fas fa-map-marker-alt"></i></a></td>
                                                                <td class="text-center"><a class="ubicarDisp cursorPointer ubicado" data-tooltip="Quitar" data-position="top center"><i class="far fa-trash-alt"></i></a></td>
                                                            </tr>
                                                            <tr>
                                                                <td>Dispositivo 1.2</td>
                                                                <td class="negative"><i class="icon close"></i> <span>No ubicado</span></td>
                                                                <td class="text-center"><a class="ubicarDisp cursorPointer" data-tooltip="Ubicar" data-position="top center"><i class="fas fa-map-marker-alt"></i></a></td>
                                                                <td class="text-center"><a class="ubicarDisp cursorPointer ubicado" data-tooltip="Quitar" data-position="top center"><i class="far fa-trash-alt"></i></a></td>
                                                            </tr>
                                                            <tr>
                                                                <td>Dispositivo 1.3</td>
                                                                <td class="negative"><i class="icon close"></i> <span>No ubicado</span></td>
                                                                <td class="text-center"><a class="ubicarDisp cursorPointer" data-tooltip="Ubicar" data-position="top center"><i class="fas fa-map-marker-alt"></i></a></td>
                                                                <td class="text-center"><a class="ubicarDisp cursorPointer ubicado" data-tooltip="Quitar" data-position="top center"><i class="far fa-trash-alt"></i></a></td>
                                                            </tr>
                                                            <tr>
                                                                <td>Dispositivo 1.4</td>
                                                                <td class="negative"><i class="icon close"></i> <span>No ubicado</span></td>
                                                                <td class="text-center"><a class="ubicarDisp cursorPointer" data-tooltip="Ubicar" data-position="top center"><i class="fas fa-map-marker-alt"></i></a></td>
                                                                <td class="text-center"><a class="ubicarDisp cursorPointer ubicado" data-tooltip="Quitar" data-position="top center"><i class="far fa-trash-alt"></i></a></td>
                                                            </tr>
                                                            <tr>
                                                                <td>Dispositivo 1.5</td>
                                                                <td class="negative"><i class="icon close"></i> <span>No ubicado</span></td>
                                                                <td class="text-center"><a class="ubicarDisp cursorPointer" data-tooltip="Ubicar" data-position="top center"><i class="fas fa-map-marker-alt"></i></a></td>
                                                                <td class="text-center"><a class="ubicarDisp cursorPointer ubicado" data-tooltip="Quitar" data-position="top center"><i class="far fa-trash-alt"></i></a></td>
                                                            </tr>
                                                            <tr>
                                                                <td>Dispositivo 1.6</td>
                                                                <td class="negative"><i class="icon close"></i> <span>No ubicado</span></td>
                                                                <td class="text-center"><a class="ubicarDisp cursorPointer" data-tooltip="Ubicar" data-position="top center"><i class="fas fa-map-marker-alt"></i></a></td>
                                                                <td class="text-center"><a class="ubicarDisp cursorPointer ubicado" data-tooltip="Quitar" data-position="top center"><i class="far fa-trash-alt"></i></a></td>
                                                            </tr>
                                                        </tbody>
                                                    </table>
                                                </div>
                                            </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="list border-15">
                        <div class="plantaImage">
                            <img alt="" src="assets/images/planta.png">
                        </div>
                    </div>
            </section>

        </div>
        <div class="ui red small message quitMarker">
            Has quitado el Dispositivo X de la imagen
        </div>
        <div class="ui blue red small message addMarker">
            Ya puedes ubicar el Dispositivo X en la imagen
        </div>
        <div class="ui blue red small message reAddMarker">
            Ya puedes reubicar el Dispositivo X en la imagen
        </div>
    </div>

<!--footer class="site-footer">
    <div class="ui container">
        <a href="#" class="logo logo--size-sm logo--opacity-30"></a>
        <ul class="site-footer__data">
            <li>Sucre 942, PB2, CABA.</li>
            <li>(011) 6091-4859</li>
            <li>Ventas: ventas@powermeter.com.ar</li>
            <li>Consultas Técnicas: info@powermeter.com.ar</li>
        </ul>
    </div>
</footer-->

<footer class="home-footer">
    <div class="ui grid middle aligned">
      <div class="one wide column aligned">
      </div>
      <div class="one wide column aligned lineImage">
        <img class="lineImage" src="assets/images/pie-logo-home.png" alt="">
      </div>
      <div class="column w-1 lineImage">
        <img src="assets/images/pie-linea-horizontal.png" alt="">
      </div>
      <div class="column aligned w-15 lineImage">
        <img src="assets/images/pie-logo-power.png" alt="">
      </div>
      <div class="column w-1 lineImage">
        <img src="assets/images/pie-linea-horizontal.png" alt="">
      </div>
      <div class="column w-20 lineImage">
        <ul class="site-footer-data">
          <li>Sucre 942, PB2, CABA.</li>
          <li>(011) 6091-4859</li>
          <li>Ventas: ventas@powermeter.com.ar</li>
          <li>Consultas Técnicas: info@powermeter.com.ar</li>
        </ul>
      </div>
    </div>
  </footer>
<!-- jQuery (https://jquery.com) -->
<script type="text/javascript" src="/assets/js/jquery-3.2.1.min.js"></script>

<!-- Semantic UI (https://semantic-ui.com) -->
<script type="text/javascript" src="/assets/js/semantic.min.js"></script>

<!-- Semantic UI Calendar (https://github.com/mdehoog/Semantic-UI-Calendar) -->
<script type="text/javascript" src="/assets/js/calendar.min.js"></script>

<!-- Slick carousel (http://kenwheeler.github.io/slick) -->
<script type="text/javascript" src="/assets/js/slick.min.js"></script>

<!-- Form validation (https://semantic-ui.com/behaviors/form.html) -->
<script type="text/javascript" src="/assets/js/form.min.js"></script>

<!-- Funciones propias -->
<script type="text/javascript" src="/assets/js/app.min.js"></script>

<script>
    var colores_fases_solidos = {
        'R': 'rgba(255, 99, 132, 0.8)',
        'S': 'rgba(0, 195, 165, 0.8)',
        'T': 'rgba(255, 180, 40, 0.8)',
        'total': 'rgba(100, 100, 100, 0.8)',
    };

    var colores_fases_transparentes = {
        'R': 'rgba(255, 99, 132, 0.3)',
        'S': 'rgba(0, 195, 165, 0.3)',
        'T': 'rgba(255, 180, 40, 0.3)',
        'total': 'rgba(100, 100, 100, 0.3)',
    }

    var colores_simples_solidos = {
        'principal': 'rgba(0, 195, 165, 0.8)',
        'secundario': 'rgba(69, 69, 69, 0.8)',
    }

    var colores_simples_transparentes = {
        'principal': 'rgba(0, 195, 165, 0.3)',
        'secundario': 'rgba(69, 69, 69, 0.3)',
    }
</script>

<script>

$('.ui.pointing.dropdown')
    .dropdown();

$(document).ready(function() {

    var itsTrue = false;

    var firstClick = false;

    $(".ubicarMarker").click(function() {
        itsTrue = true;
        $(".cursorDif").css("cursor", "url(assets/images/marker.png), auto");
        if(firstClick == true){
            //$(".marker").remove();
            $(".marker").css("opacity", "0.6")
            firstClick = false;
            $(".reAddMarker").css("display", "block")
            setTimeout(function() {
                $(".reAddMarker").css("display", "none");
            }, 5000);
        }else{
            $(".addMarker").css("display", "block")
            setTimeout(function() {
                $(".addMarker").css("display", "none");
            }, 5000);
        }
    });

    $(".quitarMarker").click(function() {
        $(".marker").remove();
        $(".quitMarker").css("display", "block");
        setTimeout(function() {
            $(".quitMarker").css("display", "none");
        }, 5000);
        $(".placedOrNot").removeClass("positive");
        $(".placedOrNot").addClass("negative");
        $(".placedOrNot i").removeClass("checkmark");
        $(".placedOrNot i").addClass("close");
        $(".placedOrNot span").text("No ubicado");
        $(".quitarMarker").addClass("ubicado");
        $(".ubicarMarker i").removeClass("fa-arrows-alt");
        $(".ubicarMarker i").addClass("fa-map-marker-alt");
        $(".ubicarMarker").removeAttr('data-tooltip');
        $(".ubicarMarker").attr('data-tooltip', 'Ubicar');

        firstClick = false;
    });

    $(".plantaImage img").click(function(ev) {
        if (itsTrue == true) {
            $(".marker").remove();
            mouseX = ev.pageX;
            mouseY = ev.pageY;
            console.log(mouseX + ' ' + mouseY);
            var color = '#258F9D';
            var size = '24px';
            var marker = 'url(assets/images/marker.png)';
            $("body").append(
                $('<div class="marker" data-tooltip="Dispositivo 1.0" data-position="bottom right"><div class="ui card" id="contentInMarker"><div class="content"><p class="header">Dispositivo 1.0.0</p></div><div class="description">Potencia en kW<br>Energia en kWh</div><button class="closePlantaPopUp" title="Cerrar" aria-label="Cerrar" type="button"><i class="fas fa-times"></i></button></div></div>')
                .css('position', 'absolute')
                .css('top', mouseY + 'px')
                .css('left', mouseX + 'px')
                .css('width', size)
                .css('height', size)
                .css('background', marker)
            );
            itsTrue = false;
            $(".cursorDif").css("cursor", "default");
            $(".placedOrNot").removeClass("negative");
            $(".placedOrNot").addClass("positive");
            $(".placedOrNot i").removeClass("close");
            $(".placedOrNot i").addClass("checkmark");
            $(".placedOrNot span").text("Ubicado");
            $(".quitarMarker").removeClass("ubicado");
            $(".ubicarMarker i").removeClass("fa-map-marker-alt");
            $(".ubicarMarker i").addClass("fa-arrows-alt");
            $(".ubicarMarker").removeAttr('data-tooltip');
            $(".ubicarMarker").attr('data-tooltip', 'Reubicar');
            firstClick = true;
        }
    });


    $(window).resize(function() {
        var newx = $('.marker').offset().left;
        $(".marker").css("left", newx);
        console.log("Funciona");
        console.log(newx);

        var newy = $('.marker').offset().top;
        $(".marker").css("top", newy);
        console.log("Funciona dos");
        console.log(newy);
    });
});
</script>

<script type="text/javascript" src="/assets/js/gauge.min.js"></script>
<script type="text/javascript" src="https://www.amcharts.com/lib/3/amcharts.js"></script>
<script type="text/javascript" src="https://www.amcharts.com/lib/3/serial.js"></script>
<script type="text/javascript" src="https://www.amcharts.com/lib/3/pie.js"></script>
<script src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.10.19/js/dataTables.semanticui.min.js"></script>
<script src="https://cdn.datatables.net/responsive/2.2.3/js/dataTables.responsive.min.js"></script>
<script src="https://cdn.datatables.net/responsive/2.2.3/js/responsive.semanticui.min.js"></script>
<script async defer src="https://maps.googleapis.com/maps/api/js?key=AIzaSyDDWvAXG9wEM-iOAgSmAan2fStp0BQGcDc&callback=initMap"></script>
<script src="assets/js/main.js"></script>
</body>
<script>
$(document).ready(function() {

    $oneClick = false;

    $(document).on('click', '.marker', function(){
        if($oneClick == false){
            $(".ui.card").css("display", "block");
            $oneClick = true;
        }else{
            $(".ui.card").css("display", "none");
            $oneClick = false;
        }

    });

    $(document).on('click', '#showInfoMarkers', function(){
        if($oneClick == false){
            $(".ui.card").css("display", "block");
            $oneClick = true;
        }else{
            $(".ui.card").css("display", "none");
            $oneClick = false;
        }

    });
});
</script>
</html>
