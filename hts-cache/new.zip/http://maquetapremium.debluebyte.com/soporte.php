<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="utf-8"/>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="theme-color" content="00C3A5"/>
<title>Powermeter</title>
<link rel="stylesheet" media="all" href="/assets/css/screen.css"/>
<link rel="stylesheet" media="all" href="/assets/css/_calendar.css"/>
<link rel="stylesheet" media="all" href="/assets/css/min/style.min.css"/>
<link rel="icon" type="image/png" sizes="32x32" href="/assets/images/favicon-32x32.png">
<link rel="icon" type="image/png" sizes="16x16" href="/assets/images/favicon-16x16.png">


    <link rel="stylesheet" href="https://cdn.datatables.net/1.10.19/css/dataTables.semanticui.min.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/responsive/2.2.3/css/responsive.semanticui.min.css">
    <!-- SEMANTIC UI-->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/semantic-ui@2.4.2/dist/semantic.min.css">
    <!-- Font Awesome-->
    <script src="https://kit.fontawesome.com/c43c022dac.js" crossorigin="anonymous"></script>

</head>
<body class="soporteBB">
<header class="site-header header--fixed">
    <div class="sidebarControl">
        <div class="logo logo--size-sm" id="logoSidebar"></div>
    </div>

    <!--a href="#" class="" id="sidebarControl">
        <i class="fas fa-bars"></i>
    </a-->


    <a href="#" class="btn-hamburger"><span></span></a>
    <div class="site-header__menu">
        <a href="#" class="btn-close"></a>
        <nav class="site-header__nav">
            <a href="" class="item" data-tooltip="Notificaciones" data-position="bottom right">
                <img alt="" src="assets/images/campana.png">
            </a>
            <a href="configuracion.php" class="item configuracionTop" data-tooltip="Configuración" data-position="bottom right">
                <img alt="" src="assets/images/config.png">
            </a>
            <a href="soporte.php" class="soporteTop" data-tooltip="Soporte" data-position="bottom right">
                <img alt="" src="assets/images/faqs.png">
            </a>
            <a id="logout" href="" data-username="Nombre Apellido" data-tooltip="Log Out" data-position="bottom right">
                <img alt="" src="assets/images/logout.png">
            </a>
        </nav>
        <!--/header-nav-->
        <ul class="site-header__data">
            <li>Sucre 942, PB2, CABA.</li>
            <li>(011) 6091-4859</li>
            <li>Ventas: ventas@powermeter.com.ar</li>
            <li>Consultas Técnicas: info@powermeter.com.ar</li>
        </ul>
        <div class="logo logo--white logo--size-sm logo--opacity-60"></div>
    </div>
</header>

<nav class="main-menu">
    <ul class="accordionUl">
        <div class="ui vertical accordion menu">
            <div class="item simulatedMenu">
                <i class="fas fa-bars"></i>
            </div>
            <div class="item resumenSection">
                <a class="title withSub withoutAfter">
                    <img alt="" src="assets/images/first-menu.png" style="width:26px; height:26px;">
                    <span class="nav-text">
                        Resumen
                    </span>
                    <!--h4 class="showTitle">Resumen</h4-->
                </a>
                <div class="content">
                    <ul>
                        <li>
                            <a href="index.php">Dashboard</a>
                        </li>
                        <li>
                            <a href="mapa.php">Mapa</a>
                        </li>
                        <!--li>
                            <a href="lista.php">Lista</a>
                        </li-->
                        <li>
                            <a href="planta.php">Planta</a>
                        </li>
                    </ul>
                </div>
            </div>
            <div class="item">
                <a href="facturacion.php" class="title withoutAfter onlyLink">
                    <img alt="" src="assets/images/five-menu.png" style="width:26px; height:26px;">
                    <span class="nav-text">
                        Facturación
                    </span>
                    <!--h4 class="showTitle">Facturación</h4-->
                </a>
            </div>
            <div class="item">
                <a class="title withoutAfter onlyLink">
                    <img alt="" src="assets/images/second-menu.png" style="width:26px; height:26px;">
                    <span class="nav-text">
                        Auditor
                    </span>
                    <!--h4 class="showTitle">Auditor</h4-->
                </a>
            </div>
            <div class="item deSeparador"></div>
            <div class="item analisisSection">
                <a class="title withSub withoutAfter">
                    <img alt="" src="assets/images/four-menu.png" style="width:26px; height:26px;">
                    <span class="nav-text">
                        Análisis
                    </span>
                    <!--h4 class="showTitle">Análisis</h4-->
                </a>
                <div class="content">
                    <ul>
                        <li>
                            <a href="instantaneos.php">Instantáneos</a>
                        </li>
                        <li>
                            <a href="historicos.php">Históricos</a>
                        </li>
                        <li>
                            <a href="calidad.php">Calidad</a>
                        </li>
                        <li>
                            <a href="stand-by.php">Stand-by</a>
                        </li>
                        <li>
                            <a href="eventos.php">Eventos</a>
                        </li>
                    </ul>
                </div>
            </div>
            <div class="item">
                <a class="title withoutAfter onlyLink">
                    <img alt="" src="assets/images/six-menu.png" style="width:26px; height:26px;">
                    <span class="nav-text">
                        Control
                    </span>
                    <!--h4 class="showTitle">Control</h4-->
                </a>
            </div>
        </div>
    </ul>
    <!--ul class="logout">
        <li>
           <a href="#" class="containDesc" id="closeSidebar" data-tooltip="Abrir menú" data-position="top left">
                 <i class="fas fa-chevron-right"></i>
                <span class="nav-text">

                </span>
            </a>
        </li>
    </ul-->
</nav>

<div class="dimDiv"></div>



<script>
    $('.ui.accordion').accordion({'exclusive': false});
</script>

<div class="block block--device bg-color withSideMenu">
    <div class="ui secondary pointing menu custom-menu customBread">
        <div class="oneColumn">
            <p class="customBreadText">Soporte</p>
        </div>

        <div class="secondColumn"></div>
    </div>
    <div class="container-full">
        <section class="block block--devices" id="soporte">
            <!--EVENTOS-->
            <div class="mb-25 border-15">
                <div class="ui equal width aligned padded grid newConfig">
                    <div class="ui styled fluid accordion faqs">
                        <h5>Preguntas frecuentes</h5>
                        <div class="active title"><i class="dropdown icon"></i> ¿Qué es la interfaz web?</div>
                        <div class="active content">
                            <p>Es un sistema de software en la nube diseñado para ser utilizado con los productos Powermeter, y explotar así al máximo sus funcionalidades.</p>
                        </div>
                        <div class="title"><i class="dropdown icon"></i> ¿Con qué productos se puede utilizar?</div>
                        <div class="content">
                            <p>Es un sistema de software en la nube diseñado para ser utilizado con los productos Powermeter, y explotar así al máximo sus funcionalidades.</p>
                        </div>
                        <div class="title"><i class="dropdown icon"></i> ¿Cuánto cuesta utilizar la interfaz web?</div>
                        <div class="content">
                            <p>Es un sistema de software en la nube diseñado para ser utilizado con los productos Powermeter, y explotar así al máximo sus funcionalidades.</p>
                        </div>
                        <div class="title"><i class="dropdown icon"></i> ¿Por qué utilizar la interfaz web con Powermeter SMART?</div>
                        <div class="content">
                            <p>Es un sistema de software en la nube diseñado para ser utilizado con los productos Powermeter, y explotar así al máximo sus funcionalidades.</p>
                        </div>
                    </div>
                </div>
            </div>
            <!--EVENTOS-->
        </section>
    </div>
</div>


<!--footer class="site-footer">
    <div class="ui container">
        <a href="#" class="logo logo--size-sm logo--opacity-30"></a>
        <ul class="site-footer__data">
            <li>Sucre 942, PB2, CABA.</li>
            <li>(011) 6091-4859</li>
            <li>Ventas: ventas@powermeter.com.ar</li>
            <li>Consultas Técnicas: info@powermeter.com.ar</li>
        </ul>
    </div>
</footer-->

<footer class="home-footer">
    <div class="ui grid middle aligned">
      <div class="one wide column aligned">
      </div>
      <div class="one wide column aligned lineImage">
        <img class="lineImage" src="assets/images/pie-logo-home.png" alt="">
      </div>
      <div class="column w-1 lineImage">
        <img src="assets/images/pie-linea-horizontal.png" alt="">
      </div>
      <div class="column aligned w-15 lineImage">
        <img src="assets/images/pie-logo-power.png" alt="">
      </div>
      <div class="column w-1 lineImage">
        <img src="assets/images/pie-linea-horizontal.png" alt="">
      </div>
      <div class="column w-20 lineImage">
        <ul class="site-footer-data">
          <li>Sucre 942, PB2, CABA.</li>
          <li>(011) 6091-4859</li>
          <li>Ventas: ventas@powermeter.com.ar</li>
          <li>Consultas Técnicas: info@powermeter.com.ar</li>
        </ul>
      </div>
    </div>
  </footer>
<!-- jQuery (https://jquery.com) -->
<script type="text/javascript" src="/assets/js/jquery-3.2.1.min.js"></script>

<!-- Semantic UI (https://semantic-ui.com) -->
<script type="text/javascript" src="/assets/js/semantic.min.js"></script>

<!-- Semantic UI Calendar (https://github.com/mdehoog/Semantic-UI-Calendar) -->
<script type="text/javascript" src="/assets/js/calendar.min.js"></script>

<!-- Slick carousel (http://kenwheeler.github.io/slick) -->
<script type="text/javascript" src="/assets/js/slick.min.js"></script>

<!-- Form validation (https://semantic-ui.com/behaviors/form.html) -->
<script type="text/javascript" src="/assets/js/form.min.js"></script>

<!-- Funciones propias -->
<script type="text/javascript" src="/assets/js/app.min.js"></script>

<script>
    var colores_fases_solidos = {
        'R': 'rgba(255, 99, 132, 0.8)',
        'S': 'rgba(0, 195, 165, 0.8)',
        'T': 'rgba(255, 180, 40, 0.8)',
        'total': 'rgba(100, 100, 100, 0.8)',
    };

    var colores_fases_transparentes = {
        'R': 'rgba(255, 99, 132, 0.3)',
        'S': 'rgba(0, 195, 165, 0.3)',
        'T': 'rgba(255, 180, 40, 0.3)',
        'total': 'rgba(100, 100, 100, 0.3)',
    }

    var colores_simples_solidos = {
        'principal': 'rgba(0, 195, 165, 0.8)',
        'secundario': 'rgba(69, 69, 69, 0.8)',
    }

    var colores_simples_transparentes = {
        'principal': 'rgba(0, 195, 165, 0.3)',
        'secundario': 'rgba(69, 69, 69, 0.3)',
    }
</script>

<script>

</script>
<script type="text/javascript" src="/assets/js/gauge.min.js"></script>
<script type="text/javascript" src="https://www.amcharts.com/lib/3/amcharts.js"></script>
<script type="text/javascript" src="https://www.amcharts.com/lib/3/serial.js"></script>
<script type="text/javascript" src="https://www.amcharts.com/lib/3/pie.js"></script>
<script src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.10.19/js/dataTables.semanticui.min.js"></script>
<script src="https://cdn.datatables.net/responsive/2.2.3/js/dataTables.responsive.min.js"></script>
<script src="https://cdn.datatables.net/responsive/2.2.3/js/responsive.semanticui.min.js"></script>
<script src="assets/js/main.js"></script>
</body>
</html>
