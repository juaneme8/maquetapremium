<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="utf-8"/>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="theme-color" content="00C3A5"/>
<title>Powermeter</title>
<link rel="stylesheet" media="all" href="/assets/css/screen.css"/>
<link rel="stylesheet" media="all" href="/assets/css/_calendar.css"/>
<link rel="stylesheet" media="all" href="/assets/css/min/style.min.css"/>
<link rel="icon" type="image/png" sizes="32x32" href="/assets/images/favicon-32x32.png">
<link rel="icon" type="image/png" sizes="16x16" href="/assets/images/favicon-16x16.png">


    <link rel="stylesheet" href="https://cdn.datatables.net/1.10.19/css/dataTables.semanticui.min.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/responsive/2.2.3/css/responsive.semanticui.min.css">
    <!-- SEMANTIC UI-->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/semantic-ui@2.4.2/dist/semantic.min.css">
    <!-- Font Awesome-->
    <script src="https://kit.fontawesome.com/c43c022dac.js" crossorigin="anonymous"></script>
</head>
<body class="resumenBB">
<header class="site-header header--fixed">
    <div class="sidebarControl">
        <div class="logo logo--size-sm" id="logoSidebar"></div>
    </div>

    <!--a href="#" class="" id="sidebarControl">
        <i class="fas fa-bars"></i>
    </a-->


    <a href="#" class="btn-hamburger"><span></span></a>
    <div class="site-header__menu">
        <a href="#" class="btn-close"></a>
        <nav class="site-header__nav">
            <a href="" class="item" data-tooltip="Notificaciones" data-position="bottom right">
                <img alt="" src="assets/images/campana.png">
            </a>
            <a href="configuracion.php" class="item configuracionTop" data-tooltip="Configuración" data-position="bottom right">
                <img alt="" src="assets/images/config.png">
            </a>
            <a href="soporte.php" class="soporteTop" data-tooltip="Soporte" data-position="bottom right">
                <img alt="" src="assets/images/faqs.png">
            </a>
            <a id="logout" href="" data-username="Nombre Apellido" data-tooltip="Log Out" data-position="bottom right">
                <img alt="" src="assets/images/logout.png">
            </a>
        </nav>
        <!--/header-nav-->
        <ul class="site-header__data">
            <li>Sucre 942, PB2, CABA.</li>
            <li>(011) 6091-4859</li>
            <li>Ventas: ventas@powermeter.com.ar</li>
            <li>Consultas Técnicas: info@powermeter.com.ar</li>
        </ul>
        <div class="logo logo--white logo--size-sm logo--opacity-60"></div>
    </div>
</header>

<nav class="main-menu">
    <ul class="accordionUl">
        <div class="ui vertical accordion menu">
            <div class="item simulatedMenu">
                <i class="fas fa-bars"></i>
            </div>
            <div class="item resumenSection">
                <a class="title withSub withoutAfter">
                    <img alt="" src="assets/images/first-menu.png" style="width:26px; height:26px;">
                    <span class="nav-text">
                        Resumen
                    </span>
                    <!--h4 class="showTitle">Resumen</h4-->
                </a>
                <div class="content">
                    <ul>
                        <li>
                            <a href="index.php">Dashboard</a>
                        </li>
                        <li>
                            <a href="mapa.php">Mapa</a>
                        </li>
                        <!--li>
                            <a href="lista.php">Lista</a>
                        </li-->
                        <li>
                            <a href="planta.php">Planta</a>
                        </li>
                    </ul>
                </div>
            </div>
            <div class="item">
                <a href="facturacion.php" class="title withoutAfter onlyLink">
                    <img alt="" src="assets/images/five-menu.png" style="width:26px; height:26px;">
                    <span class="nav-text">
                        Facturación
                    </span>
                    <!--h4 class="showTitle">Facturación</h4-->
                </a>
            </div>
            <div class="item">
                <a class="title withoutAfter onlyLink">
                    <img alt="" src="assets/images/second-menu.png" style="width:26px; height:26px;">
                    <span class="nav-text">
                        Auditor
                    </span>
                    <!--h4 class="showTitle">Auditor</h4-->
                </a>
            </div>
            <div class="item deSeparador"></div>
            <div class="item analisisSection">
                <a class="title withSub withoutAfter">
                    <img alt="" src="assets/images/four-menu.png" style="width:26px; height:26px;">
                    <span class="nav-text">
                        Análisis
                    </span>
                    <!--h4 class="showTitle">Análisis</h4-->
                </a>
                <div class="content">
                    <ul>
                        <li>
                            <a href="instantaneos.php">Instantáneos</a>
                        </li>
                        <li>
                            <a href="historicos.php">Históricos</a>
                        </li>
                        <li>
                            <a href="calidad.php">Calidad</a>
                        </li>
                        <li>
                            <a href="stand-by.php">Stand-by</a>
                        </li>
                        <li>
                            <a href="eventos.php">Eventos</a>
                        </li>
                    </ul>
                </div>
            </div>
            <div class="item">
                <a class="title withoutAfter onlyLink">
                    <img alt="" src="assets/images/six-menu.png" style="width:26px; height:26px;">
                    <span class="nav-text">
                        Control
                    </span>
                    <!--h4 class="showTitle">Control</h4-->
                </a>
            </div>
        </div>
    </ul>
    <!--ul class="logout">
        <li>
           <a href="#" class="containDesc" id="closeSidebar" data-tooltip="Abrir menú" data-position="top left">
                 <i class="fas fa-chevron-right"></i>
                <span class="nav-text">

                </span>
            </a>
        </li>
    </ul-->
</nav>

<div class="dimDiv"></div>



<script>
    $('.ui.accordion').accordion({'exclusive': false});
</script>

    <div class="block block--device bg-color withSideMenu">
        <div class="ui secondary pointing menu custom-menu customBread">
            <div class="oneColumn">
                <p class="customBreadText configSelect">Configuración - <span>Organización</span></p>
            </div>

            <div class="secondColumn">
                <div class="ui vertical labeled open-filters">
                    <button id="openNewForm" class="ui btnOk">
                        <p>Nuevo</p>
                    </button>
                </div>
                <div class="ui vertical labeled open-filters">
                    <button id="showEnterpriseUl" class="ui btnOk">
                        <p>Dispositivos</p>
                    </button>
                </div>
                <div class="ui vertical labeled open-filters">
                    <button id="showGroupeUl" class="ui btnOk">
                        <p>Grupos</p>
                    </button>
                </div>
            </div>
        </div>
        <div class="container-full">
            <section class="block block--devices" id="localizaciones">

                <div class="ui equal width center aligned padded grid newConfig borderLineInstant mb-25 bg-white">
                    <div class="row information">
                        <div class="column">
                            <div class="ui two column grid equal height stackable">
                                <div class="row dispositivosList">
                                    <div class="column deviceColumn">
                                        <ul class="enterpriseUl">
                                            <!--COMIENZA EMPRESA-->
                                            <li class="empresaLiFirst contractAll" style="margin-bottom:40px;">
                                                <a class="" data-tooltip="Contraer todo" data-position="top left"><i class="fas far fa-chevron-down"></i></a>
                                            </li>

                                            <li class="empresaLi">
                                                <button class="ui button enterpriseBtn"><i class="fas fa-plus"></i> Empresa 1</button>
                                                <a class="anchorBtn enterpriseBtnA"><i class="fas fa-chevron-down"></i></a>
                                            </li>

                                                <div class="contZona">
                                                    <li class="zonaLi">
                                                        <button class="ui button zonaBtn"><i class="fas fa-plus"></i> Zona 1.1</button>
                                                        <a class="anchorBtn"><i class="fas fa-chevron-down"></i></a>
                                                    </li>

                                                    <div class="contLocalizacion">
                                                        <li class="localizacionLi">
                                                            <button class="ui button localizacionBtn"><i class="fas fa-plus"></i><i class="fas fa-map-marker-alt"></i> Localización 1.1.1</button>
                                                            <a class="anchorBtn"><i class="fas fa-chevron-down"></i></a>
                                                        </li>

                                                        <div class="contSubLocalizacion">
                                                            <li class="subLocalizacionLi">
                                                                <button class="ui button sublocalizacionBtn"><i class="fas fa-plus"></i>- Sublocalización 1.1.1.1</button>
                                                                <a class="anchorBtn"><i class="fas fa-chevron-down"></i></a>
                                                            </li>

                                                            <div class="contDispositivo">
                                                                <li class="dispositivoLi">
                                                                    <button class="ui button dispositivoBtn"><i class="fas fa-plus"></i>. Dispositivo 1.1.1.1</button>
                                                                </li>

                                                                <li class="dispositivoLi">
                                                                    <button class="ui button dispositivoBtn"><i class="fas fa-plus"></i>. Dispositivo 1.1.1.2</button>
                                                                </li>
                                                            </div>

                                                            <li class="subLocalizacionLi">
                                                                <button class="ui button sublocalizacionBtn"><i class="fas fa-plus"></i>- Sublocalización 1.1.1.2</button>
                                                                <a class="anchorBtn"><i class="fas fa-chevron-down"></i></a>
                                                            </li>

                                                            <div class="contDispositivo">
                                                                <li class="dispositivoLi">
                                                                    <button class="ui button dispositivoBtn"><i class="fas fa-plus"></i>. Dispositivo 1.1.2.1</button>
                                                                </li>

                                                                <li class="dispositivoLi">
                                                                    <button class="ui button dispositivoBtn"><i class="fas fa-plus"></i>. Dispositivo 1.1.2.2</button>
                                                                </li>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            <!--FINALIZA EMPRESA-->

                                            <!--SEPARADOR-->
                                            <!--li class="companySeparator"></li-->

                                            <!--COMIENZA EMPRESA-->
                                            <li class="empresaLi withMarginTop">
                                                <button class="ui button enterpriseBtn"><i class="fas fa-plus"></i> Empresa 1</button>
                                                <a class="anchorBtn enterpriseBtnA"><i class="fas fa-chevron-down"></i></a>
                                            </li>

                                                <div class="contZona">
                                                    <li class="zonaLi">
                                                        <button class="ui button zonaBtn"><i class="fas fa-plus"></i> Zona 1.1</button>
                                                        <a class="anchorBtn"><i class="fas fa-chevron-down"></i></a>
                                                    </li>

                                                    <div class="contLocalizacion">
                                                        <li class="localizacionLi">
                                                            <button class="ui button localizacionBtn"><i class="fas fa-plus"></i><i class="fas fa-map-marker-alt"></i> Localización 1.1.1</button>
                                                            <a class="anchorBtn"><i class="fas fa-chevron-down"></i></a>
                                                        </li>

                                                        <div class="contSubLocalizacion">
                                                            <li class="subLocalizacionLi">
                                                                <button class="ui button sublocalizacionBtn"><i class="fas fa-plus"></i>- Sublocalización 1.1.1.1</button>
                                                                <a class="anchorBtn"><i class="fas fa-chevron-down"></i></a>
                                                            </li>

                                                            <div class="contDispositivo">
                                                                <li class="dispositivoLi">
                                                                    <button class="ui button dispositivoBtn"><i class="fas fa-plus"></i>. Dispositivo 1.1.1.1</button>
                                                                </li>

                                                                <li class="dispositivoLi">
                                                                    <button class="ui button dispositivoBtn"><i class="fas fa-plus"></i>. Dispositivo 1.1.1.2</button>
                                                                </li>
                                                            </div>

                                                            <li class="subLocalizacionLi">
                                                                <button class="ui button sublocalizacionBtn"><i class="fas fa-plus"></i>- Sublocalización 1.1.1.2</button>
                                                                <a class="anchorBtn"><i class="fas fa-chevron-down"></i></a>
                                                            </li>

                                                            <div class="contDispositivo">
                                                                <li class="dispositivoLi">
                                                                    <button class="ui button dispositivoBtn"><i class="fas fa-plus"></i>. Dispositivo 1.1.2.1</button>
                                                                </li>

                                                                <li class="dispositivoLi">
                                                                    <button class="ui button dispositivoBtn"><i class="fas fa-plus"></i>. Dispositivo 1.1.2.2</button>
                                                                </li>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            <!--FINALIZA EMPRESA-->
                                        </ul>

                                        <ul class="groupeUl">
                                            <!--COMIENZA GRUPOS-->
                                            <li class="grupoLi">
                                                <button class="ui button groupGrupoBtn"><i class="fas fa-plus"></i> Grupo A</button>
                                            </li>

                                            <li class="grupoLi">
                                                <button class="ui button groupGrupoBtn"><i class="fas fa-plus"></i> Grupo B</button>
                                            </li>

                                            <li class="grupoLi">
                                                <button class="ui button groupGrupoBtn"><i class="fas fa-plus"></i> Grupo C</button>
                                            </li>
                                            <!--FINALIZA GRUPOS-->
                                        </ul>
                                    </div>

                                    <!--COMIENZAN LOS FORMULARIOS-->
                                    <div class="column formColumn">
                                        <!--FORMULARIO DE EMPRESA-->
                                        <form class="ui form gralForm" id="enterpriseForm">
                                            <h2 class="secondGeneralTitle">Empresa</h2>
                                            <div class="field">
                                                <label class="typeTitle">Nombre *</label>
                                                <input placeholder="Nombre" type="text" class="inputStyle">
                                            </div>

                                            <div class="field">
                                                <label class="typeTitle">Descripción</label>
                                                <input placeholder="Descripcion" type="text" class="inputStyle">
                                            </div>

                                            <div class="field">
                                                <label class="typeTitle">Dirección</label>
                                                <input class="inputStyle" id="autocomplete" placeholder="Dirección" onFocus="geolocate()" type="text"/>
                                            </div>

                                            <div class="field">
                                                <label class="typeTitle">Teléfono</label>
                                                <input placeholder="Teléfono" type="text" class="inputStyle">
                                            </div>

                                            <div class="field imageUp">
                                                <!--div class="ui icon button" id="toolTipI" data-tooltip="Las imagenes deben estar en formato .png con una resolucion maxima de 300x300px">
                                                    <i class="info circle icon"></i>
                                                </div-->
                                                <label class="typeTitle">Imagen</label>
                                                <label for="file" class="ui icon button imageSelection" data-tooltip="Las imagenes deben estar en formato .png con una resolucion maxima de 300x300px">
                                                    <i class="file icon"></i> Seleccionar
                                                </label>
                                                <img width="30px" height="30px" id="blah" src="assets/images/hoverUp.png" alt="" style="">
                                                <input type="file" id="file" style="display:none">
                                            </div>

                                            <div class="mt-25 formBtns">
                                                <a href="" class="ui btnCancel">Cancelar</a>
                                                <a href="" class="ui btnOk">Guardar</a>
                                            </div>
                                        </form>

                                        <!--FORMULARIO DE ZONA-->
                                        <form class="ui form gralForm" id="zonaForm">
                                            <h2 class="secondGeneralTitle">Zona</h2>
                                            <div class="field">
                                                <label class="typeTitle">Empresa *</label>
                                                <div class="ui selection dropdown">
                                                    <div class="default text textSelect">Seleccionar</div>
                                                    <i class="dropdown icon"></i>
                                                    <input type="hidden" name="gender">
                                                    <div class="menu">
                                                        <div class="item" data-value="nivel">Empresa 1</div>
                                                        <div class="item" data-value="grupo">Empresa 1.2</div>
                                                        <div class="item" data-value="nivel">Empresa 1.3</div>
                                                        <div class="item" data-value="grupo">Empresa 1.4</div>
                                                        <div class="item" data-value="grupo">Empresa 1.5</div>
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="field">
                                                <label class="typeTitle">Nombre *</label>
                                                <input placeholder="Nombre" type="text" class="inputStyle">
                                            </div>

                                            <div class="field">
                                                <label class="typeTitle">Descripción</label>
                                                <input placeholder="Descripción" type="text" class="inputStyle">
                                            </div>

                                            <div class="field">
                                                <label class="typeTitle">Dirección</label>
                                                <input class="inputStyle" id="autocomplete" placeholder="Dirección" onFocus="geolocate()" type="text"/>
                                            </div>

                                            <div class="field">
                                                <label class="typeTitle">Teléfono</label>
                                                <input placeholder="Teléfono" type="text" class="inputStyle">
                                            </div>

                                            <div class="mt-25 formBtns">
                                                <a href="" class="ui btnCancel">Cancelar</a>
                                                <a href="" class="ui btnOk">Guardar</a>
                                            </div>
                                        </form>

                                        <!--FORMULARIO DE LOZALIZACION-->
                                        <form class="ui form gralForm" id="localizacionForm">
                                            <h2 class="secondGeneralTitle">Lozalización</h2>
                                            <div class="field">
                                                <label class="typeTitle">Empresa *</label>
                                                <div class="ui selection dropdown">
                                                    <div class="default text textSelect">Seleccionar</div>
                                                    <i class="dropdown icon"></i>
                                                    <input type="hidden" name="gender">
                                                    <div class="menu">
                                                        <div class="item" data-value="nivel">Empresa 1</div>
                                                        <div class="item" data-value="grupo">Empresa 1.2</div>
                                                        <div class="item" data-value="nivel">Empresa 1.3</div>
                                                        <div class="item" data-value="grupo">Empresa 1.4</div>
                                                        <div class="item" data-value="grupo">Empresa 1.5</div>
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="field">
                                                <label class="typeTitle">Zona *</label>
                                                <div class="ui selection dropdown">
                                                    <div class="default text textSelect">Seleccionar</div>
                                                    <i class="dropdown icon"></i>
                                                    <input type="hidden" name="gender">
                                                    <div class="menu">
                                                        <div class="item" data-value="nivel">Zona 1</div>
                                                        <div class="item" data-value="grupo">Zona 1.2</div>
                                                        <div class="item" data-value="nivel">Zona 1.3</div>
                                                        <div class="item" data-value="grupo">Zona 1.4</div>
                                                        <div class="item" data-value="grupo">Zona 1.5</div>
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="field">
                                                <label class="typeTitle">Nombre *</label>
                                                <input placeholder="Nombre" type="text" class="inputStyle">
                                            </div>

                                            <div class="field">
                                                <label class="typeTitle">Descripción</label>
                                                <input placeholder="Descripción" type="text" class="inputStyle">
                                            </div>

                                            <div class="field">
                                                <label class="typeTitle">Dirección</label>
                                                <input class="inputStyle" id="autocomplete" placeholder="Dirección" onFocus="geolocate()" type="text"/>
                                            </div>

                                            <div class="field">
                                                <label class="typeTitle">Teléfono</label>
                                                <input placeholder="Teléfono" type="text" class="inputStyle">
                                            </div>

                                            <div class="field imageUp">
                                                <!--div class="ui icon button" id="toolTipI" data-tooltip="Las imagenes deben estar en formato .png con una resolucion maxima de 300x300px">
                                                    <i class="info circle icon"></i>
                                                </div-->
                                                <label class="typeTitle">Imagen</label>
                                                <label for="file" class="ui icon button imageSelection" data-tooltip="Las imagenes deben estar en formato .png con una resolucion maxima de 300x300px">
                                                    <i class="file icon"></i> Seleccionar
                                                </label>
                                                <img width="30px" height="30px" id="blah" src="assets/images/hoverUp.png" alt="" style="">
                                                <input type="file" id="file" style="display:none">
                                            </div>

                                            <div class="field imageUp">
                                                <!--div class="ui icon button" id="toolTipI" data-tooltip="Las imagenes deben estar en formato .png con una resolucion maxima de 300x300px">
                                                    <i class="info circle icon"></i>
                                                </div-->
                                                <label class="typeTitle">Plano de planta</label>
                                                <label for="file" class="ui icon button imageSelection" data-tooltip="Las imagenes deben estar en formato .png con una resolucion maxima de 300x300px">
                                                    <i class="file icon"></i> Seleccionar
                                                </label>
                                                <img width="30px" height="30px" id="blah" src="assets/images/hoverUp.png" alt="" style="">
                                                <input type="file" id="file" style="display:none">
                                            </div>

                                            <div class="field">
                                                <label class="typeTitle">Horario laboral</label>

                                                <div class="day">
                                                    <p class="dayTitle">Día de la semana</p>

                                                    <p class="dayTitle">Horas desde:</p>

                                                    <p class="dayTitle">Horas hasta</p>
                                                </div>

                                                <div class="day">
                                                    <div class="ui checkbox">
                                                        <input type="checkbox">
                                                        <label>Lunes</label>
                                                    </div>

                                                    <div class="timeInput">
                                                        <p>Desde:</p>
                                                        <input class="inputStyle" type="time" name="">
                                                    </div>

                                                    <div class="timeInput">
                                                        <p>Hasta:</p>
                                                        <input class="inputStyle" type="time" name="">
                                                    </div>
                                                </div>

                                                <div class="day">
                                                    <div class="ui checkbox">
                                                        <input type="checkbox">
                                                        <label>Martes</label>
                                                    </div>

                                                    <div class="timeInput">
                                                        <p>Desde:</p>
                                                        <input class="inputStyle" type="time" name="">
                                                    </div>

                                                    <div class="timeInput">
                                                        <p>Hasta:</p>
                                                        <input class="inputStyle" type="time" name="">
                                                    </div>
                                                </div>

                                                <div class="day">
                                                    <div class="ui checkbox">
                                                        <input type="checkbox">
                                                        <label>Miércoles</label>
                                                    </div>

                                                    <div class="timeInput">
                                                        <p>Desde:</p>
                                                        <input class="inputStyle" type="time" name="">
                                                    </div>

                                                    <div class="timeInput">
                                                        <p>Hasta:</p>
                                                        <input class="inputStyle" type="time" name="">
                                                    </div>
                                                </div>

                                                <div class="day">
                                                    <div class="ui checkbox">
                                                        <input type="checkbox">
                                                        <label>Jueves</label>
                                                    </div>

                                                    <div class="timeInput">
                                                        <p>Desde:</p>
                                                        <input class="inputStyle" type="time" name="">
                                                    </div>

                                                    <div class="timeInput">
                                                        <p>Hasta:</p>
                                                        <input class="inputStyle" type="time" name="">
                                                    </div>
                                                </div>

                                                <div class="day">
                                                    <div class="ui checkbox">
                                                        <input type="checkbox">
                                                        <label>Viernes</label>
                                                    </div>

                                                    <div class="timeInput">
                                                        <p>Desde:</p>
                                                        <input class="inputStyle" type="time" name="">
                                                    </div>

                                                    <div class="timeInput">
                                                        <p>Hasta:</p>
                                                        <input class="inputStyle" type="time" name="">
                                                    </div>
                                                </div>

                                                <div class="day">
                                                    <div class="ui checkbox">
                                                        <input type="checkbox">
                                                        <label>Sábado</label>
                                                    </div>

                                                    <div class="timeInput">
                                                        <p>Desde:</p>
                                                        <input class="inputStyle" type="time" name="">
                                                    </div>

                                                    <div class="timeInput">
                                                        <p>Hasta:</p>
                                                        <input class="inputStyle" type="time" name="">
                                                    </div>
                                                </div>

                                                <div class="day">
                                                    <div class="ui checkbox">
                                                        <input type="checkbox">
                                                        <label>Domingo</label>
                                                    </div>

                                                    <div class="timeInput">
                                                        <p>Desde:</p>
                                                        <input class="inputStyle" type="time" name="">
                                                    </div>

                                                    <div class="timeInput">
                                                        <p>Hasta:</p>
                                                        <input class="inputStyle" type="time" name="">
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="row dispositivos mb-25">
                                                <table class="customTable generalTables">
                                                    <tr>
                                                        <td class="dispColumn">
                                                            <p>Dispositivos libres:</p>
                                                            <select class="dispList" multiple="multiple" id='lstBox1'>
                                                                  <option value="">Dispositivo 1</option>
                                                                  <option value="">Dispositivo 2</option>
                                                                  <option value="">Dispositivo 3</option>
                                                                  <option value="">Dispositivo 4</option>
                                                                  <option value="">Dispositivo 5</option>
                                                                  <option value="">Dispositivo 6</option>
                                                            </select>
                                                        </td>
                                                        <td class="btnColumn">
                                                            <input type='button' id='btnRightAll' value ='  >>  '/>
                                                            <input type='button' id='btnRight' value ='  >  '/>
                                                            <input type='button' id='btnLeft' value ='  <  '/>
                                                            <input type='button' id='btnLeftAll' value ='  <<  '/>
                                                        </td>
                                                        <td class="dispColumn">
                                                            <p>Dispositivos asignados: </p>
                                                            <select class="dispList" multiple="" id='lstBox2'>
                                                                <option value="">Dispositivo 7</option>
                                                                <option value="">Dispositivo 8</option>
                                                                <option value="">Dispositivo 9</option>
                                                                <option value="">Dispositivo 10</option>
                                                                <option value="">Dispositivo 11</option>
                                                                <option value="">Dispositivo 12</option>
                                                            </select>
                                                        </td>
                                                    </tr>
                                                </table>
                                            </div>

                                            <div class="row roles">
                                                <table class="ui celled table newCustomTable generalTables">
                                                    <thead>
                                                        <tr>
                                                            <th>Usuario</th>
                                                            <th>Mail</th>
                                                            <th>Permisos</th>
                                                            <th>Estado</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        <tr>
                                                            <td data-label="Name">Nombre</td>
                                                            <td data-label="">Mail</td>
                                                            <td data-label="">Permisos</td>
                                                            <td data-label="">Estado</td>
                                                            <td class="tdIcon" data-label=""><a href=""><img src="assets/images/pencil.png" style="width: 15px;height: 18px;"></a></td>
                                                            <td class="tdIcon" data-label=""><a href=""><img src="assets/images/trash.png" style="width: 15px;height: 18px;"></a></td>
                                                        </tr>
                                                        <tr>
                                                            <td data-label="Name">Nombre</td>
                                                            <td data-label="">Mail</td>
                                                            <td data-label="">Permisos</td>
                                                            <td data-label="">Estado</td>
                                                            <td class="tdIcon" data-label=""><a href=""><img src="assets/images/pencil.png" style="width: 15px;height: 18px;"></a></td>
                                                            <td class="tdIcon" data-label=""><a href=""><img src="assets/images/trash.png" style="width: 15px;height: 18px;"></a></td>
                                                        </tr>
                                                    </tbody>
                                                </table>

                                                <div class="addUser">
                                                    <a href="">Agregar usuario +</a>
                                                </div>
                                            </div>

                                            <div class="mt-25 formBtns">
                                                <a href="" class="ui btnCancel">Cancelar</a>
                                                <a href="" class="ui btnOk">Guardar</a>
                                            </div>
                                        </form>

                                        <!--FORMULARIO DE SUB-LOZALIZACION-->
                                        <form class="ui form gralForm" id="subLocalizacionForm">
                                            <h2 class="secondGeneralTitle">Sublocalización</h2>
                                            <div class="field">
                                                <label class="typeTitle">Empresa *</label>
                                                <div class="ui selection dropdown">
                                                    <div class="default text textSelect">Seleccionar</div>
                                                    <i class="dropdown icon"></i>
                                                    <input type="hidden" name="gender">
                                                    <div class="menu">
                                                        <div class="item" data-value="nivel">Empresa 1</div>
                                                        <div class="item" data-value="grupo">Empresa 1.2</div>
                                                        <div class="item" data-value="nivel">Empresa 1.3</div>
                                                        <div class="item" data-value="grupo">Empresa 1.4</div>
                                                        <div class="item" data-value="grupo">Empresa 1.5</div>
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="field">
                                                <label class="typeTitle">Zona *</label>
                                                <div class="ui selection dropdown">
                                                    <div class="default text textSelect">Seleccionar</div>
                                                    <i class="dropdown icon"></i>
                                                    <input type="hidden" name="gender">
                                                    <div class="menu">
                                                        <div class="item" data-value="nivel">Zona 1</div>
                                                        <div class="item" data-value="grupo">Zona 1.2</div>
                                                        <div class="item" data-value="nivel">Zona 1.3</div>
                                                        <div class="item" data-value="grupo">Zona 1.4</div>
                                                        <div class="item" data-value="grupo">Zona 1.5</div>
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="field">
                                                <label class="typeTitle">Localización *</label>
                                                <div class="ui selection dropdown">
                                                    <div class="default text textSelect">Seleccionar</div>
                                                    <i class="dropdown icon"></i>
                                                    <input type="hidden" name="gender">
                                                    <div class="menu">
                                                        <div class="item" data-value="nivel">Localización 1</div>
                                                        <div class="item" data-value="grupo">Localización 1.2</div>
                                                        <div class="item" data-value="nivel">Localización 1.3</div>
                                                        <div class="item" data-value="grupo">Localización 1.4</div>
                                                        <div class="item" data-value="grupo">Localización 1.5</div>
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="field">
                                                <label class="typeTitle">Nombre *</label>
                                                <input placeholder="Nombre" type="text" class="inputStyle">
                                            </div>

                                            <div class="field">
                                                <label class="typeTitle">Descripción</label>
                                                <input placeholder="Descripción" type="text" class="inputStyle">
                                            </div>

                                            <div class="field">
                                                <label class="typeTitle">Dirección</label>
                                                <input class="inputStyle" id="autocomplete" placeholder="Dirección" onFocus="geolocate()" type="text"/>
                                            </div>

                                            <div class="field">
                                                <label class="typeTitle">Teléfono</label>
                                                <input placeholder="Teléfono" type="text" class="inputStyle">
                                            </div>

                                            <div class="field imageUp">
                                                <!--div class="ui icon button" id="toolTipI" data-tooltip="Las imagenes deben estar en formato .png con una resolucion maxima de 300x300px">
                                                    <i class="info circle icon"></i>
                                                </div-->
                                                <label class="typeTitle">Imagen</label>
                                                <label for="file" class="ui icon button imageSelection" data-tooltip="Las imagenes deben estar en formato .png con una resolucion maxima de 300x300px">
                                                    <i class="file icon"></i> Seleccionar
                                                </label>
                                                <img width="30px" height="30px" id="blah" src="assets/images/hoverUp.png" alt="" style="">
                                                <input type="file" id="file" style="display:none">
                                            </div>

                                            <div class="field imageUp">
                                                <!--div class="ui icon button" id="toolTipI" data-tooltip="Las imagenes deben estar en formato .png con una resolucion maxima de 300x300px">
                                                    <i class="info circle icon"></i>
                                                </div-->
                                                <label class="typeTitle">Plano de planta</label>
                                                <label for="file" class="ui icon button imageSelection" data-tooltip="Las imagenes deben estar en formato .png con una resolucion maxima de 300x300px">
                                                    <i class="file icon"></i> Seleccionar
                                                </label>
                                                <img width="30px" height="30px" id="blah" src="assets/images/hoverUp.png" alt="" style="">
                                                <input type="file" id="file" style="display:none">
                                            </div>

                                            <div class="field">
                                                <label class="typeTitle">Horario laboral</label>

                                                <div class="day">
                                                    <p class="dayTitle">Día de la semana</p>

                                                    <p class="dayTitle">Horas desde:</p>

                                                    <p class="dayTitle">Horas hasta</p>
                                                </div>

                                                <div class="day">
                                                    <div class="ui checkbox">
                                                        <input type="checkbox">
                                                        <label>Lunes</label>
                                                    </div>

                                                    <div class="timeInput">
                                                        <p>Desde:</p>
                                                        <input class="inputStyle" type="time" name="">
                                                    </div>

                                                    <div class="timeInput">
                                                        <p>Hasta:</p>
                                                        <input class="inputStyle" type="time" name="">
                                                    </div>
                                                </div>

                                                <div class="day">
                                                    <div class="ui checkbox">
                                                        <input type="checkbox">
                                                        <label>Martes</label>
                                                    </div>

                                                    <div class="timeInput">
                                                        <p>Desde:</p>
                                                        <input class="inputStyle" type="time" name="">
                                                    </div>

                                                    <div class="timeInput">
                                                        <p>Hasta:</p>
                                                        <input class="inputStyle" type="time" name="">
                                                    </div>
                                                </div>

                                                <div class="day">
                                                    <div class="ui checkbox">
                                                        <input type="checkbox">
                                                        <label>Miércoles</label>
                                                    </div>

                                                    <div class="timeInput">
                                                        <p>Desde:</p>
                                                        <input class="inputStyle" type="time" name="">
                                                    </div>

                                                    <div class="timeInput">
                                                        <p>Hasta:</p>
                                                        <input class="inputStyle" type="time" name="">
                                                    </div>
                                                </div>

                                                <div class="day">
                                                    <div class="ui checkbox">
                                                        <input type="checkbox">
                                                        <label>Jueves</label>
                                                    </div>

                                                    <div class="timeInput">
                                                        <p>Desde:</p>
                                                        <input class="inputStyle" type="time" name="">
                                                    </div>

                                                    <div class="timeInput">
                                                        <p>Hasta:</p>
                                                        <input class="inputStyle" type="time" name="">
                                                    </div>
                                                </div>

                                                <div class="day">
                                                    <div class="ui checkbox">
                                                        <input type="checkbox">
                                                        <label>Viernes</label>
                                                    </div>

                                                    <div class="timeInput">
                                                        <p>Desde:</p>
                                                        <input class="inputStyle" type="time" name="">
                                                    </div>

                                                    <div class="timeInput">
                                                        <p>Hasta:</p>
                                                        <input class="inputStyle" type="time" name="">
                                                    </div>
                                                </div>

                                                <div class="day">
                                                    <div class="ui checkbox">
                                                        <input type="checkbox">
                                                        <label>Sábado</label>
                                                    </div>

                                                    <div class="timeInput">
                                                        <p>Desde:</p>
                                                        <input class="inputStyle" type="time" name="">
                                                    </div>

                                                    <div class="timeInput">
                                                        <p>Hasta:</p>
                                                        <input class="inputStyle" type="time" name="">
                                                    </div>
                                                </div>

                                                <div class="day">
                                                    <div class="ui checkbox">
                                                        <input type="checkbox">
                                                        <label>Domingo</label>
                                                    </div>

                                                    <div class="timeInput">
                                                        <p>Desde:</p>
                                                        <input class="inputStyle" type="time" name="">
                                                    </div>

                                                    <div class="timeInput">
                                                        <p>Hasta:</p>
                                                        <input class="inputStyle" type="time" name="">
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="row dispositivos mb-25">
                                                <table class="customTable generalTables">
                                                    <tr>
                                                        <td class="dispColumn">
                                                            <p>Dispositivos libres:</p>
                                                            <select class="dispList" multiple="multiple" id='lstBox1'>
                                                                  <option value="">Dispositivo 1</option>
                                                                  <option value="">Dispositivo 2</option>
                                                                  <option value="">Dispositivo 3</option>
                                                                  <option value="">Dispositivo 4</option>
                                                                  <option value="">Dispositivo 5</option>
                                                                  <option value="">Dispositivo 6</option>
                                                            </select>
                                                        </td>
                                                        <td class="btnColumn">
                                                            <input type='button' id='btnRightAll' value ='  >>  '/>
                                                            <input type='button' id='btnRight' value ='  >  '/>
                                                            <input type='button' id='btnLeft' value ='  <  '/>
                                                            <input type='button' id='btnLeftAll' value ='  <<  '/>
                                                        </td>
                                                        <td class="dispColumn">
                                                            <p>Dispositivos asignados: </p>
                                                            <select class="dispList" multiple="" id='lstBox2'>
                                                                <option value="">Dispositivo 7</option>
                                                                <option value="">Dispositivo 8</option>
                                                                <option value="">Dispositivo 9</option>
                                                                <option value="">Dispositivo 10</option>
                                                                <option value="">Dispositivo 11</option>
                                                                <option value="">Dispositivo 12</option>
                                                            </select>
                                                        </td>
                                                    </tr>
                                                </table>
                                            </div>

                                            <div class="row roles">
                                                <table class="ui celled table newCustomTable generalTables">
                                                    <thead>
                                                        <tr>
                                                            <th>Usuario</th>
                                                            <th>Mail</th>
                                                            <th>Permisos</th>
                                                            <th>Estado</th>

                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        <tr>
                                                            <td data-label="Name">Nombre</td>
                                                            <td data-label="">Mail</td>
                                                            <td data-label="">Permisos</td>
                                                            <td data-label="">Estado</td>
                                                            <td class="tdIcon" data-label=""><a href=""><img src="assets/images/pencil.png" style="width: 15px;height: 18px;"></a></td>
                                                            <td class="tdIcon" data-label=""><a href=""><img src="assets/images/trash.png" style="width: 15px;height: 18px;"></a></td>
                                                        </tr>
                                                        <tr>
                                                            <td data-label="Name">Nombre</td>
                                                            <td data-label="">Mail</td>
                                                            <td data-label="">Permisos</td>
                                                            <td data-label="">Estado</td>
                                                            <td class="tdIcon" data-label=""><a href=""><img src="assets/images/pencil.png" style="width: 15px;height: 18px;"></a></td>
                                                            <td class="tdIcon" data-label=""><a href=""><img src="assets/images/trash.png" style="width: 15px;height: 18px;"></a></td>
                                                        </tr>
                                                    </tbody>
                                                </table>

                                                <div class="addUser">
                                                    <a href="">Agregar usuario +</a>
                                                </div>
                                            </div>

                                            <div class="mt-25 formBtns">
                                                <a href="" class="ui btnCancel">Cancelar</a>
                                                <a href="" class="ui btnOk">Guardar</a>
                                            </div>
                                        </form>

                                        <!--FORMULARIO DE DISPOSITIVO-->
                                        <form class="ui form gralForm" id="dispositivoForm">
                                            <h2 class="secondGeneralTitle">Dispositivo</h2>
                                            <div class="field">
                                                <label class="typeTitle">Empresa *</label>
                                                <div class="ui selection dropdown">
                                                    <div class="default text textSelect">Seleccionar</div>
                                                    <i class="dropdown icon"></i>
                                                    <input type="hidden" name="gender">
                                                    <div class="menu">
                                                        <div class="item" data-value="nivel">Empresa 1</div>
                                                        <div class="item" data-value="grupo">Empresa 1.2</div>
                                                        <div class="item" data-value="nivel">Empresa 1.3</div>
                                                        <div class="item" data-value="grupo">Empresa 1.4</div>
                                                        <div class="item" data-value="grupo">Empresa 1.5</div>
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="field">
                                                <label class="typeTitle">Zona *</label>
                                                <div class="ui selection dropdown">
                                                    <div class="default text textSelect">Seleccionar</div>
                                                    <i class="dropdown icon"></i>
                                                    <input type="hidden" name="gender">
                                                    <div class="menu">
                                                        <div class="item" data-value="nivel">Zona 1</div>
                                                        <div class="item" data-value="grupo">Zona 1.2</div>
                                                        <div class="item" data-value="nivel">Zona 1.3</div>
                                                        <div class="item" data-value="grupo">Zona 1.4</div>
                                                        <div class="item" data-value="grupo">Zona 1.5</div>
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="field">
                                                <label class="typeTitle">Localización *</label>
                                                <div class="ui selection dropdown">
                                                    <div class="default text textSelect">Seleccionar</div>
                                                    <i class="dropdown icon"></i>
                                                    <input type="hidden" name="gender">
                                                    <div class="menu">
                                                        <div class="item" data-value="nivel">Localización 1</div>
                                                        <div class="item" data-value="grupo">Localización 1.2</div>
                                                        <div class="item" data-value="nivel">Localización 1.3</div>
                                                        <div class="item" data-value="grupo">Localización 1.4</div>
                                                        <div class="item" data-value="grupo">Localización 1.5</div>
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="field">
                                                <label class="typeTitle">Nombre *</label>
                                                <input placeholder="Nombre" type="text" class="inputStyle">
                                            </div>

                                            <div class="field">
                                                <label class="typeTitle">Descripción</label>
                                                <input placeholder="Descripción" type="text" class="inputStyle">
                                            </div>

                                            <div class="field">
                                                <label class="typeTitle">Nombre de la fase R</label>
                                                <input placeholder="Nombre de la fase R" type="text" class="inputStyle">
                                            </div>

                                            <div class="field">
                                                <label class="typeTitle">Nombre de la fase S</label>
                                                <input placeholder="Nombre de la fase S" type="text" class="inputStyle">
                                            </div>

                                            <div class="field">
                                                <label class="typeTitle">Nombre de la fase T</label>
                                                <input placeholder="Nombre de la fase T" type="text" class="inputStyle">
                                            </div>

                                            <div class="field">
                                                <label class="typeTitle">Grupo</label>
                                                <div class="ui selection dropdown">
                                                    <div class="default text textSelect">Seleccionar</div>
                                                    <i class="dropdown icon"></i>
                                                    <input type="hidden" name="gender">
                                                    <div class="menu">
                                                        <div class="item" data-value="nivel">Grupo 1</div>
                                                        <div class="item" data-value="grupo">Grupo 1.2</div>
                                                        <div class="item" data-value="nivel">Grupo 1.3</div>
                                                        <div class="item" data-value="grupo">Grupo 1.4</div>
                                                        <div class="item" data-value="grupo">Grupo 1.5</div>
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="row dispositivos mb-25">
                                                <table class="customTable generalTables">
                                                    <tr>
                                                        <td class="dispColumn">
                                                            <p>Dispositivos no asignados:</p>
                                                            <select class="dispList" multiple="multiple" id='lstBox1'>
                                                                  <option value="">Dispositivo 1</option>
                                                                  <option value="">Dispositivo 2</option>
                                                                  <option value="">Dispositivo 3</option>
                                                                  <option value="">Dispositivo 4</option>
                                                                  <option value="">Dispositivo 5</option>
                                                                  <option value="">Dispositivo 6</option>
                                                            </select>
                                                        </td>
                                                        <td class="btnColumn">
                                                            <input type='button' id='btnRightAll' value ='  >>  '/>
                                                            <input type='button' id='btnRight' value ='  >  '/>
                                                            <input type='button' id='btnLeft' value ='  <  '/>
                                                            <input type='button' id='btnLeftAll' value ='  <<  '/>
                                                        </td>
                                                        <td class="dispColumn">
                                                            <p>Dispositivos asignados: </p>
                                                            <select class="dispList" multiple="" id='lstBox2'>
                                                                <option value="">Dispositivo 7</option>
                                                                <option value="">Dispositivo 8</option>
                                                                <option value="">Dispositivo 9</option>
                                                                <option value="">Dispositivo 10</option>
                                                                <option value="">Dispositivo 11</option>
                                                                <option value="">Dispositivo 12</option>
                                                            </select>
                                                        </td>
                                                    </tr>
                                                </table>
                                            </div>

                                            <div class="row asociacion">
                                                <table class="ui celled table newCustomTable generalTables">
                                                    <thead>
                                                        <tr>
                                                            <th>Tensión</th>
                                                            <th>Corriente</th>
                                                            <th>Potencia</th>
                                                            <th>Energía</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        <tr>
                                                            <td data-label="Name">Dispositivo 1</td>
                                                            <td data-label="">
                                                                <select class="ui search dropdown">
                                                                    <option value="">Seleccionar</option>
                                                                    <option value="em">&#60;=</option>
                                                                    <option value="em">+</option>
                                                                    <option value="em">-</option>
                                                                    <option value="em">Nada</option>
                                                                </select>
                                                            </td>
                                                            <td data-label="">
                                                                <select class="ui search dropdown">
                                                                    <option value="">Seleccionar</option>
                                                                    <option value="em">&#60;=</option>
                                                                    <option value="em">+</option>
                                                                    <option value="em">-</option>
                                                                    <option value="em">Nada</option>
                                                                </select>
                                                            </td>
                                                            <td data-label="">
                                                                <select class="ui search dropdown">
                                                                    <option value="">Seleccionar</option>
                                                                    <option value="em">&#60;=</option>
                                                                    <option value="em">+</option>
                                                                    <option value="em">-</option>
                                                                    <option value="em">Nada</option>
                                                                </select>
                                                            </td>
                                                            <td data-label="">
                                                                <select class="ui search dropdown">
                                                                    <option value="">Seleccionar</option>
                                                                    <option value="em">&#60;=</option>
                                                                    <option value="em">+</option>
                                                                    <option value="em">-</option>
                                                                    <option value="em">Nada</option>
                                                                </select>
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <td data-label="Name">Dispositivo 2</td>
                                                            <td data-label="">
                                                                <select class="ui search dropdown">
                                                                    <option value="">Seleccionar</option>
                                                                    <option value="em">&#60;=</option>
                                                                    <option value="em">+</option>
                                                                    <option value="em">-</option>
                                                                    <option value="em">Nada</option>
                                                                </select>
                                                            </td>
                                                            <td data-label="">
                                                                <select class="ui search dropdown">
                                                                    <option value="">Seleccionar</option>
                                                                    <option value="em">&#60;=</option>
                                                                    <option value="em">+</option>
                                                                    <option value="em">-</option>
                                                                    <option value="em">Nada</option>
                                                                </select>
                                                            </td>
                                                            <td data-label="">
                                                                <select class="ui search dropdown">
                                                                    <option value="">Seleccionar</option>
                                                                    <option value="em">&#60;=</option>
                                                                    <option value="em">+</option>
                                                                    <option value="em">-</option>
                                                                    <option value="em">Nada</option>
                                                                </select>
                                                            </td>
                                                            <td data-label="">
                                                                <select class="ui search dropdown">
                                                                    <option value="">Seleccionar</option>
                                                                    <option value="em">&#60;=</option>
                                                                    <option value="em">+</option>
                                                                    <option value="em">-</option>
                                                                    <option value="em">Nada</option>
                                                                </select>
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <td data-label="Name">Dispositivo 3</td>
                                                            <td data-label="">
                                                                <select class="ui search dropdown">
                                                                    <option value="">Seleccionar</option>
                                                                    <option value="em">&#60;=</option>
                                                                    <option value="em">+</option>
                                                                    <option value="em">-</option>
                                                                    <option value="em">Nada</option>
                                                                </select>
                                                            </td>
                                                            <td data-label="">
                                                                <select class="ui search dropdown">
                                                                    <option value="">Seleccionar</option>
                                                                    <option value="em">&#60;=</option>
                                                                    <option value="em">+</option>
                                                                    <option value="em">-</option>
                                                                    <option value="em">Nada</option>
                                                                </select>
                                                            </td>
                                                            <td data-label="">
                                                                <select class="ui search dropdown">
                                                                    <option value="">Seleccionar</option>
                                                                    <option value="em">&#60;=</option>
                                                                    <option value="em">+</option>
                                                                    <option value="em">-</option>
                                                                    <option value="em">Nada</option>
                                                                </select>
                                                            </td>
                                                            <td data-label="">
                                                                <select class="ui search dropdown">
                                                                    <option value="">Seleccionar</option>
                                                                    <option value="em">&#60;=</option>
                                                                    <option value="em">+</option>
                                                                    <option value="em">-</option>
                                                                    <option value="em">Nada</option>
                                                                </select>
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <td data-label="Name">Dispositivo N</td>
                                                            <td data-label="">
                                                                <select class="ui search dropdown">
                                                                    <option value="">Seleccionar</option>
                                                                    <option value="em">&#60;=</option>
                                                                    <option value="em">+</option>
                                                                    <option value="em">-</option>
                                                                    <option value="em">Nada</option>
                                                                </select>
                                                            </td>
                                                            <td data-label="">
                                                                <select class="ui search dropdown">
                                                                    <option value="">Seleccionar</option>
                                                                    <option value="em">&#60;=</option>
                                                                    <option value="em">+</option>
                                                                    <option value="em">-</option>
                                                                    <option value="em">Nada</option>
                                                                </select>
                                                            </td>
                                                            <td data-label="">
                                                                <select class="ui search dropdown">
                                                                    <option value="">Seleccionar</option>
                                                                    <option value="em">&#60;=</option>
                                                                    <option value="em">+</option>
                                                                    <option value="em">-</option>
                                                                    <option value="em">Nada</option>
                                                                </select>
                                                            </td>
                                                            <td data-label="">
                                                                <select class="ui search dropdown">
                                                                    <option value="">Seleccionar</option>
                                                                    <option value="em">&#60;=</option>
                                                                    <option value="em">+</option>
                                                                    <option value="em">-</option>
                                                                    <option value="em">Nada</option>
                                                                </select>
                                                            </td>
                                                        </tr>
                                                    </tbody>
                                                </table>
                                            </div>

                                            <div class="mt-25 formBtns">
                                                <a href="" class="ui btnCancel">Cancelar</a>
                                                <a href="" class="ui btnOk">Guardar</a>
                                            </div>
                                        </form>

                                        <!--FORMULARIO DE GRUPO EDITAR/CONFIGURAR-->
                                        <form class="ui form gralForm" id="editGroupForm">
                                            <h2 class="secondGeneralTitle">Grupo</h2>

                                            <div class="field">
                                                <label class="typeTitle">Nombre *</label>
                                                <input placeholder="Nombre" type="text" class="inputStyle">
                                            </div>

                                            <div class="field">
                                                <label class="typeTitle">Descripción</label>
                                                <input placeholder="Descripción" type="text" class="inputStyle">
                                            </div>

                                            <div class="field imageUp">
                                                <!--div class="ui icon button" id="toolTipI" data-tooltip="Las imagenes deben estar en formato .png con una resolucion maxima de 300x300px">
                                                    <i class="info circle icon"></i>
                                                </div-->
                                                <label class="typeTitle">Imagen</label>
                                                <label for="file" class="ui icon button imageSelection" data-tooltip="Las imagenes deben estar en formato .png con una resolucion maxima de 300x300px">
                                                    <i class="file icon"></i> Seleccionar
                                                </label>
                                                <img width="30px" height="30px" id="blah" src="assets/images/hoverUp.png" alt="" style="">
                                                <input type="file" id="file" style="display:none">
                                            </div>

                                            <div class="field">
                                                <label class="typeTitle">Empresa *</label>
                                                <div class="ui selection dropdown">
                                                    <div class="default text textSelect">Seleccionar</div>
                                                    <i class="dropdown icon"></i>
                                                    <input type="hidden" name="gender">
                                                    <div class="menu">
                                                        <div class="item" data-value="nivel">Empresa 1</div>
                                                        <div class="item" data-value="grupo">Empresa 1.2</div>
                                                        <div class="item" data-value="nivel">Empresa 1.3</div>
                                                        <div class="item" data-value="grupo">Empresa 1.4</div>
                                                        <div class="item" data-value="grupo">Empresa 1.5</div>
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="field">
                                                <label class="typeTitle">Zona *</label>
                                                <div class="ui selection dropdown">
                                                    <div class="default text textSelect">Seleccionar</div>
                                                    <i class="dropdown icon"></i>
                                                    <input type="hidden" name="gender">
                                                    <div class="menu">
                                                        <div class="item" data-value="nivel">Zona 1</div>
                                                        <div class="item" data-value="grupo">Zona 1.2</div>
                                                        <div class="item" data-value="nivel">Zona 1.3</div>
                                                        <div class="item" data-value="grupo">Zona 1.4</div>
                                                        <div class="item" data-value="grupo">Zona 1.5</div>
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="field">
                                                <label class="typeTitle">Localización *</label>
                                                <div class="ui selection dropdown">
                                                    <div class="default text textSelect">Seleccionar</div>
                                                    <i class="dropdown icon"></i>
                                                    <input type="hidden" name="gender">
                                                    <div class="menu">
                                                        <div class="item" data-value="nivel">Localización 1</div>
                                                        <div class="item" data-value="grupo">Localización 1.2</div>
                                                        <div class="item" data-value="nivel">Localización 1.3</div>
                                                        <div class="item" data-value="grupo">Localización 1.4</div>
                                                        <div class="item" data-value="grupo">Localización 1.5</div>
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="field">
                                                <label class="typeTitle">Sublocalización *</label>
                                                <div class="ui selection dropdown">
                                                    <div class="default text textSelect">Seleccionar</div>
                                                    <i class="dropdown icon"></i>
                                                    <input type="hidden" name="gender">
                                                    <div class="menu">
                                                        <div class="item" data-value="nivel">SubLocalización 1</div>
                                                        <div class="item" data-value="grupo">SubLocalización 1.2</div>
                                                        <div class="item" data-value="nivel">SubLocalización 1.3</div>
                                                        <div class="item" data-value="grupo">SubLocalización 1.4</div>
                                                        <div class="item" data-value="grupo">SubLocalización 1.5</div>
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="row dispositivos mb-25">
                                                <table class="customTable generalTables">
                                                    <tr>
                                                        <td class="dispColumn">
                                                            <p>Dispositivos no asignados:</p>
                                                            <select class="dispList" multiple="multiple" id='lstBox1'>
                                                                  <option value="">Dispositivo 1</option>
                                                                  <option value="">Dispositivo 2</option>
                                                                  <option value="">Dispositivo 3</option>
                                                                  <option value="">Dispositivo 4</option>
                                                                  <option value="">Dispositivo 5</option>
                                                                  <option value="">Dispositivo 6</option>
                                                            </select>
                                                        </td>
                                                        <td class="btnColumn">
                                                            <input type='button' id='btnRightAll' value ='  >>  '/>
                                                            <input type='button' id='btnRight' value ='  >  '/>
                                                            <input type='button' id='btnLeft' value ='  <  '/>
                                                            <input type='button' id='btnLeftAll' value ='  <<  '/>
                                                        </td>
                                                        <td class="dispColumn">
                                                            <p>Dispositivos asignados: </p>
                                                            <select class="dispList" multiple="" id='lstBox2'>
                                                                <option value="">Dispositivo 7</option>
                                                                <option value="">Dispositivo 8</option>
                                                                <option value="">Dispositivo 9</option>
                                                                <option value="">Dispositivo 10</option>
                                                                <option value="">Dispositivo 11</option>
                                                                <option value="">Dispositivo 12</option>
                                                            </select>
                                                        </td>
                                                    </tr>
                                                </table>
                                            </div>

                                            <div class="mt-25 formBtns">
                                                <a href="" class="ui btnCancel">Eliminar</a>
                                                <a href="" class="ui btnOk">Guardar</a>
                                            </div>
                                        </form>


                                        <!--FORMULARIO DE GRUPO NUEVO-->
                                        <form class="ui form gralForm" id="newGroupForm">
                                            <h2 class="secondGeneralTitle">Grupo</h2>

                                            <div class="field">
                                                <label class="typeTitle">Nombre *</label>
                                                <input placeholder="Nombre" type="text" class="inputStyle">
                                            </div>

                                            <div class="field">
                                                <label class="typeTitle">Descripción</label>
                                                <input placeholder="Descripción" type="text" class="inputStyle">
                                            </div>

                                            <div class="field imageUp">
                                                <!--div class="ui icon button" id="toolTipI" data-tooltip="Las imagenes deben estar en formato .png con una resolucion maxima de 300x300px">
                                                    <i class="info circle icon"></i>
                                                </div-->
                                                <label class="typeTitle">Imagen</label>
                                                <label for="file" class="ui icon button imageSelection" data-tooltip="Las imagenes deben estar en formato .png con una resolucion maxima de 300x300px">
                                                    <i class="file icon"></i> Seleccionar
                                                </label>
                                                <img width="30px" height="30px" id="blah" src="assets/images/hoverUp.png" alt="" style="">
                                                <input type="file" id="file" style="display:none">
                                            </div>

                                            <div class="mt-25 formBtns">
                                                <a href="" class="ui btnCancel">Cancelar</a>
                                                <a href="" class="ui btnOk">Guardar</a>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </section>
        </div>
    </div>

<!--MODAL DE SELECCION DE DISPOSITIVOS-->
<div class="ui modal customModal dispositivosModal">
    <!--i class="close icon"></i-->
    <div class="header">
        Dispositivos
    </div>
    <div class="content">
        <div class="ui two column grid equal height stackable">
            <div class="row">
                <div class="column organizacionCol">
                    <h3>Organización</h3>
                    <ul>
                        <li class="empresaLi">
                            <button class="ui button">Empresa 1</button>
                        </li>
                        <li class="zonaLi">
                            <button class="ui button">Zona 1.1</button>
                        </li>
                        <li class="localizacionLi">
                            <button class="ui button">Localización 1.1.1</button>
                        </li>
                        <li class="subLocalizacionLi">
                            <button class="ui button">Sublocalización 1</button>
                        </li>
                        <li class="dispositivoLi">
                            <button class="ui button">Dispositivo 1.1.1.1</button>
                        </li>
                        <li class="dispositivoLi">
                            <button class="ui button">Dispositivo 1.1.1.2</button>
                        </li>
                    </ul>
                </div>
                <div class="column gruposCol">
                    <h3>Grupos</h3>
                    <ul>
                        <li class="grupoLi">
                            <button class="ui button">Grupo 1</button>
                        </li>
                        <li class="grupoLi">
                            <button class="ui button">Grupo 2</button>
                        </li>
                        <li class="grupoLi">
                            <button class="ui button">Grupo 3</button>
                        </li>
                        <li class="grupoLi">
                            <button class="ui button">Grupo 4</button>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <div class="actions">
        <p><b>Su selección:</b> <span></span></p>
        <div class="ui button cancelTextToInput">Cancelar</div>
        <div class="ui button addTextToInput">Aceptar</div>
    </div>
</div>

<!--MODAL DE SELECCION NUEVO... EN LISTA.PHP Y CONFIGURACION.PHP-->
<div class="ui modal customModal newFormModal">
    <!--i class="close icon"></i-->
    <div class="header">
        Nuevo
    </div>
    <div class="content">
        <div class="ui one column grid equal height stackable">
            <div class="row">
                <div class="column">
                    <!--FORMULARIO DE NUEVO...-->
                    <form class="ui form gralForm" id="newForm">
                        <div class="field">
                            <label class="typeTitle">Empresa *</label>
                            <div class="ui selection dropdown">
                                <div class="default text textSelect">Seleccionar</div>
                                <i class="dropdown icon"></i>
                                <input type="hidden" class="getVlueOfNewSelect" name="gender">
                                <div class="menu">
                                    <div class="item" data-value="seleccionar" value="seleccionar" disable select>Seleccionar</div>
                                    <div class="item" data-value="empresa" value="empresa">Empresa</div>
                                    <div class="item" data-value="zona" value="zona">Zona</div>
                                    <div class="item" data-value="localizacion" value="localizacion">Localización</div>
                                    <div class="item" data-value="sublocalizacion" value="sublocalizacion">Sublocalización</div>
                                    <div class="item" data-value="grupo" value="grupo">Grupo</div>
                                    <div class="item" data-value="medidorvirtual" value="medidorvirtual">Medidor virtual</div>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <div class="actions">
        <div class="ui button cancelAndDismiss">Cancelar</div>
        <div class="ui button nextFormClose">Siguiente</div>
    </div>
</div>

<!--MODAL DE SELECCION DE DISPOSITIVOS-->
<div class="ui modal customModal dispositivosModalEditInsta">
    <!--i class="close icon"></i-->
    <div class="header">
        Editar
    </div>
    <div class="content">
        <div class="ui two column grid equal height stackable">
            <div class="row">
                <div class="column gruposCol">
                    <h3>Su selección</h3>
                    <ul class="addLiToEdit">
                        <!--li class="grupoLi">
                            Primera selección
                            <div class="deleteSelectionEdit"><i class="fas fa-times"></i></div>
                        </li-->
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <div class="actions">
        <!--div class="ui button cancelTextToInputEdit">Cancelar</div-->
        <div class="ui button deleteAllElements">Eliminar todo</div>
        <div class="ui button addTextToInputEdit">Aceptar</div>
    </div>
</div>

<!--MODAL DE SELECCION DE DISPOSITIVOS-->
<div class="ui modal customModal confirmDeleteAll">
    <!--i class="close icon"></i-->
    <!--div class="header">
        Editar
    </div-->
    <div class="content">
        <div class="ui one column grid equal height stackable">
            <div class="row">
                <div class="column gruposCol">
                    <h3>¿Desea eliminar todos los elementos seleccionados?</h3>
                </div>
            </div>
        </div>
    </div>
    <div class="actions">
        <!--div class="ui button cancelTextToInputEdit">Cancelar</div-->
        <div class="ui button cancelDelete">Cancelar</div>
        <div class="ui button confirmDelete">Aceptar</div>
    </div>
</div>

<!--footer class="site-footer">
    <div class="ui container">
        <a href="#" class="logo logo--size-sm logo--opacity-30"></a>
        <ul class="site-footer__data">
            <li>Sucre 942, PB2, CABA.</li>
            <li>(011) 6091-4859</li>
            <li>Ventas: ventas@powermeter.com.ar</li>
            <li>Consultas Técnicas: info@powermeter.com.ar</li>
        </ul>
    </div>
</footer-->

<footer class="home-footer">
    <div class="ui grid middle aligned">
      <div class="one wide column aligned">
      </div>
      <div class="one wide column aligned lineImage">
        <img class="lineImage" src="assets/images/pie-logo-home.png" alt="">
      </div>
      <div class="column w-1 lineImage">
        <img src="assets/images/pie-linea-horizontal.png" alt="">
      </div>
      <div class="column aligned w-15 lineImage">
        <img src="assets/images/pie-logo-power.png" alt="">
      </div>
      <div class="column w-1 lineImage">
        <img src="assets/images/pie-linea-horizontal.png" alt="">
      </div>
      <div class="column w-20 lineImage">
        <ul class="site-footer-data">
          <li>Sucre 942, PB2, CABA.</li>
          <li>(011) 6091-4859</li>
          <li>Ventas: ventas@powermeter.com.ar</li>
          <li>Consultas Técnicas: info@powermeter.com.ar</li>
        </ul>
      </div>
    </div>
  </footer>
<!-- jQuery (https://jquery.com) -->
<script type="text/javascript" src="/assets/js/jquery-3.2.1.min.js"></script>

<!-- Semantic UI (https://semantic-ui.com) -->
<script type="text/javascript" src="/assets/js/semantic.min.js"></script>

<!-- Semantic UI Calendar (https://github.com/mdehoog/Semantic-UI-Calendar) -->
<script type="text/javascript" src="/assets/js/calendar.min.js"></script>

<!-- Slick carousel (http://kenwheeler.github.io/slick) -->
<script type="text/javascript" src="/assets/js/slick.min.js"></script>

<!-- Form validation (https://semantic-ui.com/behaviors/form.html) -->
<script type="text/javascript" src="/assets/js/form.min.js"></script>

<!-- Funciones propias -->
<script type="text/javascript" src="/assets/js/app.min.js"></script>

<script>
    var colores_fases_solidos = {
        'R': 'rgba(255, 99, 132, 0.8)',
        'S': 'rgba(0, 195, 165, 0.8)',
        'T': 'rgba(255, 180, 40, 0.8)',
        'total': 'rgba(100, 100, 100, 0.8)',
    };

    var colores_fases_transparentes = {
        'R': 'rgba(255, 99, 132, 0.3)',
        'S': 'rgba(0, 195, 165, 0.3)',
        'T': 'rgba(255, 180, 40, 0.3)',
        'total': 'rgba(100, 100, 100, 0.3)',
    }

    var colores_simples_solidos = {
        'principal': 'rgba(0, 195, 165, 0.8)',
        'secundario': 'rgba(69, 69, 69, 0.8)',
    }

    var colores_simples_transparentes = {
        'principal': 'rgba(0, 195, 165, 0.3)',
        'secundario': 'rgba(69, 69, 69, 0.3)',
    }
</script>

<script async defer src="https://maps.googleapis.com/maps/api/js?key=AIzaSyDDWvAXG9wEM-iOAgSmAan2fStp0BQGcDc&callback=initMap"></script>

<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyDDWvAXG9wEM-iOAgSmAan2fStp0BQGcDc&libraries=places&callback=initAutocomplete" async defer></script>

    <script>
            var placeSearch, autocomplete;
          var componentForm = {
            street_number: 'short_name',
            route: 'long_name',
            locality: 'long_name',
            administrative_area_level_1: 'short_name',
            country: 'long_name',
            postal_code: 'short_name'
          };

          function initAutocomplete() {
            // Create the autocomplete object, restricting the search to geographical
            // location types.
            autocomplete = new google.maps.places.Autocomplete(
                /** @type {!HTMLInputElement} */(document.getElementById('autocomplete')),
                {types: ['geocode']});

            // When the user selects an address from the dropdown, populate the address
            // fields in the form.
            autocomplete.addListener('place_changed', fillInAddress);
          }



          // Bias the autocomplete object to the user's geographical location,
          // as supplied by the browser's 'navigator.geolocation' object.
          function geolocate() {
            if (navigator.geolocation) {
              navigator.geolocation.getCurrentPosition(function(position) {
                var geolocation = {
                  lat: position.coords.latitude,
                  lng: position.coords.longitude
                };
                var circle = new google.maps.Circle({
                  center: geolocation,
                  radius: position.coords.accuracy
                });
                autocomplete.setBounds(circle.getBounds());
              });
            }
          }

    $('.multi.ui.normal.dropdown')
      .dropdown({
        maxSelections: 100
      })
    ;

    $('.ui.pointing.dropdown')
      .dropdown()
    ;

</script>

<script type="text/javascript" src="/assets/js/gauge.min.js"></script>
<script type="text/javascript" src="https://www.amcharts.com/lib/3/amcharts.js"></script>
<script type="text/javascript" src="https://www.amcharts.com/lib/3/serial.js"></script>
<script type="text/javascript" src="https://www.amcharts.com/lib/3/pie.js"></script>
<script src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.10.19/js/dataTables.semanticui.min.js"></script>
<script src="https://cdn.datatables.net/responsive/2.2.3/js/dataTables.responsive.min.js"></script>
<script src="https://cdn.datatables.net/responsive/2.2.3/js/responsive.semanticui.min.js"></script>
<script src="assets/js/main.js"></script>


</body>
</html>
